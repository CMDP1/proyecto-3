CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  author VARCHAR(160) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  category VARCHAR(100),
  image_url VARCHAR(500),
  active BOOLEAN NOT NULL DEFAULT TRUE
);
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL,
  phone VARCHAR(40),
  address VARCHAR(500) NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status ENUM('Recibido','En preparación','Enviado','Entregado','Cancelado') NOT NULL DEFAULT 'Recibido',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  book_id INT NOT NULL,
  book_title VARCHAR(180) NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (book_id) REFERENCES books(id)
);
INSERT INTO books (title,author,description,price,stock,category,image_url) VALUES
('Cien años de soledad','Gabriel García Márquez','Una novela fundamental de la literatura latinoamericana.',289.00,20,'Novela','https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600'),
('El principito','Antoine de Saint-Exupéry','Un relato sobre la amistad, la imaginación y la vida.',149.00,35,'Clásicos','https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600'),
('Hábitos atómicos','James Clear','Métodos prácticos para construir buenos hábitos.',329.00,18,'Desarrollo personal','https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=600'),
('Pedro Páramo','Juan Rulfo','Una obra esencial de la narrativa mexicana.',179.00,24,'Literatura mexicana','https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=600'),
('El arte de la guerra','Sun Tzu','Tratado clásico sobre estrategia.',119.00,30,'Historia','https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=600');
