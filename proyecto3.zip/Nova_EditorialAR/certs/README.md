Coloca aquí los archivos fullchain.pem y privkey.pem cuando tengas un dominio y un certificado TLS válido.
Para producción, configura un servidor HTTP-01 de ACME/Let's Encrypt y monta los certificados en Nginx.
No uses certificados autofirmados para un sitio público.
