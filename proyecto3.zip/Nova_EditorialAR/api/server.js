const express = require('express');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const app = express();
app.use(helmet());
app.use(express.json({ limit: '100kb' }));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: 'appuser',
  password: process.env.MYSQL_PASSWORD,
  database: 'nova_editorial',
  waitForConnections: true,
  connectionLimit: 10
});
const secret = process.env.JWT_SECRET || 'development-only-secret-change-me';
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);

function adminOnly(req,res,next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try {
    req.admin = jwt.verify(token, secret);
    next();
  } catch {
    res.status(401).json({ error: 'Se requiere iniciar sesión como proveedor.' });
  }
}

app.get('/api/health', asyncRoute(async (req,res) => {
  await pool.query('SELECT 1');
  res.json({ status: 'ok', service: 'Nova / Editorial AR API', instance: process.env.INSTANCE_NAME || 'local' });
}));

app.get('/api/books', asyncRoute(async (req,res) => {
  const [rows] = await pool.query('SELECT id,title,author,description,price,stock,category,image_url FROM books WHERE active=1 ORDER BY id');
  res.json(rows);
}));

app.post('/api/admin/login', asyncRoute(async (req,res) => {
  const { username, password } = req.body || {};
  const expectedUser = process.env.ADMIN_USER || 'admin';
  const expectedPassword = process.env.ADMIN_PASSWORD || 'change-me';
  if (username !== expectedUser || !await bcrypt.compare(String(password || ''), await bcrypt.hash(expectedPassword, 10))) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }
  const token = jwt.sign({ username, role: 'provider' }, secret, { expiresIn: '8h' });
  res.json({ token, username });
}));

app.post('/api/orders', asyncRoute(async (req,res) => {
  const { customer_name, email, phone, address, items } = req.body || {};
  if (!customer_name || !email || !address || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Completa nombre, correo, dirección y agrega al menos un libro.' });
  }
  if (customer_name.length > 120 || email.length > 180 || address.length > 500) {
    return res.status(400).json({ error: 'Uno de los campos excede la longitud permitida.' });
  }
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    let total = 0;
    const normalized = [];
    for (const item of items) {
      const id = Number(item.book_id), quantity = Number(item.quantity);
      if (!Number.isInteger(id) || !Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
        throw Object.assign(new Error('Producto o cantidad no válida.'), { status: 400 });
      }
      const [[book]] = await conn.query('SELECT id,title,price,stock FROM books WHERE id=? AND active=1 FOR UPDATE', [id]);
      if (!book) throw Object.assign(new Error('Uno de los libros ya no está disponible.'), { status: 409 });
      if (book.stock < quantity) throw Object.assign(new Error(`Existencia insuficiente para: ${book.title}`), { status: 409 });
      const price = Number(book.price);
      total += price * quantity;
      normalized.push({ book, quantity, price });
    }
    const [orderResult] = await conn.query(
      'INSERT INTO orders (customer_name,email,phone,address,total,status) VALUES (?,?,?,?,?,?)',
      [customer_name.trim(), email.trim(), phone || '', address.trim(), total.toFixed(2), 'Recibido']
    );
    for (const line of normalized) {
      await conn.query('INSERT INTO order_items (order_id,book_id,book_title,quantity,unit_price) VALUES (?,?,?,?,?)',
        [orderResult.insertId, line.book.id, line.book.title, line.quantity, line.price]);
      await conn.query('UPDATE books SET stock=stock-? WHERE id=?', [line.quantity, line.book.id]);
    }
    await conn.commit();
    res.status(201).json({ message: 'Pedido enviado correctamente a Editorial AR.', order_id: orderResult.insertId, total: Number(total.toFixed(2)) });
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally { conn.release(); }
}));

app.get('/api/admin/orders', adminOnly, asyncRoute(async (req,res) => {
  const [orders] = await pool.query('SELECT id,customer_name,email,phone,address,total,status,created_at FROM orders ORDER BY created_at DESC');
  for (const order of orders) {
    const [items] = await pool.query('SELECT book_title,quantity,unit_price FROM order_items WHERE order_id=?', [order.id]);
    order.items = items;
  }
  res.json(orders);
}));

app.patch('/api/admin/orders/:id/status', adminOnly, asyncRoute(async (req,res) => {
  const allowed = ['Recibido','En preparación','Enviado','Entregado','Cancelado'];
  const status = req.body && req.body.status;
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Estado no permitido.' });
  const [result] = await pool.query('UPDATE orders SET status=? WHERE id=?', [status, Number(req.params.id)]);
  if (!result.affectedRows) return res.status(404).json({ error: 'Pedido no encontrado.' });
  res.json({ message: 'Estado actualizado.' });
}));

app.use((err,req,res,next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'Error interno del servidor.' });
});
const port = process.env.PORT || 3000;
app.listen(port, '0.0.0.0', () => console.log(`API ${process.env.INSTANCE_NAME || ''} escuchando en ${port}`));
