const API='/api';let token=localStorage.getItem('editorialToken');
const loginPanel=document.getElementById('loginPanel'),ordersPanel=document.getElementById('ordersPanel');
function safe(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const money=n=>new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(n);
document.getElementById('loginForm').onsubmit=async e=>{e.preventDefault();let f=new FormData(e.target);let r=await fetch(API+'/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(f.entries()))});let j=await r.json();if(!r.ok){document.getElementById('loginMsg').textContent=j.error;return}token=j.token;localStorage.setItem('editorialToken',token);showPanel()};
async function showPanel(){loginPanel.classList.add('hidden');ordersPanel.classList.remove('hidden');await loadOrders()}
async function loadOrders(){
 const box=document.getElementById('orders');box.innerHTML='<p>Cargando pedidos...</p>';
 try{let r=await fetch(API+'/admin/orders',{headers:{Authorization:'Bearer '+token}});if(r.status===401){localStorage.removeItem('editorialToken');token=null;ordersPanel.classList.add('hidden');loginPanel.classList.remove('hidden');return}let data=await r.json();
 if(!data.length){box.innerHTML='<div class="empty">Todavía no hay pedidos. Cuando un cliente compre en Nova, aparecerán aquí.</div>';return}
 box.innerHTML=data.map(o=>`<article class="order"><div class="order-head"><div><h3>Pedido #${o.id} · ${safe(o.customer_name)}</h3><p class="muted">${safe(o.email)} · ${safe(o.phone||'Sin teléfono')}</p><p class="muted">${safe(o.address)}</p><p class="muted">${new Date(o.created_at).toLocaleString('es-MX')}</p></div><strong>${money(Number(o.total))}</strong></div><ul>${o.items.map(i=>`<li>${safe(i.book_title)} — ${i.quantity} × ${money(Number(i.unit_price))}</li>`).join('')}</ul><div class="order-bottom"><span>Estado: <b class="status">${safe(o.status)}</b></span><select aria-label="Estado del pedido" onchange="updateStatus(${o.id},this.value)">${['Recibido','En preparación','Enviado','Entregado','Cancelado'].map(s=>`<option ${s===o.status?'selected':''}>${s}</option>`).join('')}</select></div></article>`).join('');
 }catch{box.innerHTML='<div class="empty">No se pudieron consultar los pedidos.</div>'}
}
async function updateStatus(id,status){let r=await fetch(`${API}/admin/orders/${id}/status`,{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({status})});if(!r.ok)alert('No se pudo actualizar el pedido.');await loadOrders()}
document.getElementById('refresh').onclick=loadOrders;
if(token)showPanel();
