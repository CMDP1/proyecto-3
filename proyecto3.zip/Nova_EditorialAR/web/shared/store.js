const API = '/api';
let books=[], cart=[];
const money = n => new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'}).format(n);
async function loadBooks(){
 const box=document.getElementById('books');
 try{const r=await fetch(API+'/books');if(!r.ok)throw Error();books=await r.json();
 box.innerHTML=books.map(b=>`<article class="product"><img src="${safe(b.image_url)}" alt="${safe(b.title)}"><div class="product-body"><span class="eyebrow">${safe(b.category||'LIBRO')}</span><h3>${safe(b.title)}</h3><p class="muted">${safe(b.author)}</p><p class="muted">${safe(b.description||'')}</p><div class="price">${money(Number(b.price))}</div><button class="cta" onclick="addToCart(${b.id})" ${b.stock<1?'disabled':''}>${b.stock<1?'Agotado':'Agregar al carrito'}</button></div></article>`).join('');
 }catch{box.innerHTML='<p>No fue posible cargar el catálogo. Intenta más tarde.</p>'}
}
function safe(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function addToCart(id){let b=books.find(x=>x.id===id),line=cart.find(x=>x.id===id);if(!b)return;if(line){if(line.qty>=b.stock)return alert('No hay más existencias.');line.qty++}else cart.push({id,qty:1});renderCart()}
function renderCart(){
 document.getElementById('cartCount').textContent=cart.reduce((a,x)=>a+x.qty,0);
 document.getElementById('cartItems').innerHTML=cart.length?cart.map(x=>{let b=books.find(y=>y.id===x.id);return `<div class="cart-line"><span>${safe(b.title)} × ${x.qty}</span><strong>${money(b.price*x.qty)}</strong><button onclick="removeLine(${x.id})">×</button></div>`}).join(''):'<p class="muted">Tu carrito está vacío.</p>';
 document.getElementById('cartTotal').textContent=money(cart.reduce((a,x)=>a+books.find(b=>b.id===x.id).price*x.qty,0));
}
function removeLine(id){cart=cart.filter(x=>x.id!==id);renderCart()}
document.getElementById('cartToggle').onclick=()=>document.getElementById('cart').classList.remove('hidden');
document.getElementById('closeCart').onclick=()=>document.getElementById('cart').classList.add('hidden');
document.getElementById('checkout').onsubmit=async e=>{
 e.preventDefault();let msg=document.getElementById('checkoutMsg');
 if(!cart.length){msg.textContent='Agrega al menos un libro.';return}
 const f=new FormData(e.target),data=Object.fromEntries(f.entries());
 data.items=cart.map(x=>({book_id:x.id,quantity:x.qty}));
 msg.textContent='Enviando pedido...';msg.className='message';
 try{let r=await fetch(API+'/orders',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),j=await r.json();if(!r.ok)throw Error(j.error||'No se pudo enviar');
 msg.textContent=`¡Pedido #${j.order_id} enviado a Editorial AR! Total: ${money(j.total)}.`;
 msg.className='message success';cart=[];renderCart();e.target.reset();await loadBooks();
 }catch(err){msg.textContent=err.message}
};
loadBooks();renderCart();
